import axios from 'axios';

let PAGES_CFG = {};

export function vuexPlugin(store) {
  store.registerModule('modularization', {
    state: {
      PAGES_CFG: Object.assign({}, PAGES_CFG),
      t: 111,
    },
  });
}

if (!isBrowser) {
  setInterval(async () => {
    const res = await axios.get(/* github issue中截图的配置 */ '');
    if (res.data) {
      PAGES_CFG = res.data;
    }
  }, 5000);
}
