/* eslint-disable no-use-before-define */

export default parseFn;

/**
 * 解析dom配置中的函数
 * @param  {Object} cfg       页面配置，必须包含dom属性；可能包含data，将作为部分函数表达式的作用域
 * @param  {[Object]} scope  将作为部分函数表达式的作用域，期望传入动态获取的用户数据
 * @return {Array}           解析完函数后的dom
 */
function parseFn(cfg, scope) {
  const { data, dom } = cfg;

  function expand(node) {
    const rs = dispatchFn(node, scope);
    const children = rs[2];

    if (Array.isArray(children)) {
      if (children.every(Array.isArray)) {
        rs[2] = children.map(child => expand(child)).filter(Boolean);
        return rs;
      } else if (children.length === 1) {
        return rs;
      }
      rs[2] = expand(children);
      return rs;
    }
    return rs;
  }

  return expand(dom);
}

function parseRandom(nodes, scope) {
  return dispatchFn(nodes[Math.floor(Math.random() * nodes.length)], scope);
}

function parseIf([exp, t, f], scope) {
  /* eslint-disable no-new-func */
  return dispatchFn(new Function('_S', `return ${exp}`)(scope) ? t : f);
}

/**
 * 分发函数到不同的解析器
 * @param  {Array} node  Array[fnName, ...args]
 * @param  {Object} scope 某些函数需要执行表达式需要的参数
 * @return {Array}       必须为一个dom节点类型 [tagName, attrs, children]
 */
function dispatchFn(node, scope) {
  if (!node || !Array.isArray(node) || typeof node[0] !== 'string' || !node[0].startsWith('fn-')) {
    return node;
  }

  const [fnName, ...rest] = node;
  switch (fnName.replace(/^fn-/, '')) {
    case 'random':
      return parseRandom(rest, scope);
    case 'if':
      return parseIf(rest, scope);
    default:
      return node;
  }
}

// function test() {
//   for (let i = 0; i < 10; i += 1) {
//     console.log(
//       parseFn(
//         {
//           dom: ['div', null, ['fn-if', '_S.cityIds.includes(_S.cityId)', ['fn-random', ['Foo'], ['Star']], []]],
//           data: {
//             cityIds: [1, 2, 3],
//           },
//         },
//         {
//           cityId: 3,
//         }
//       )[2]
//     );
//   }
// }
