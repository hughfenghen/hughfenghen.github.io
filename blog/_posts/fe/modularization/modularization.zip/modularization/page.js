import Vue from 'vue';
import parseFn from './fn-parser';

const ASYNC_COMPS = {
  /* 在这里注册所有异步组件 */
  Star: () => import('../components/star/star.vue'),
  Hero: () => import('../modules/tour-guide/hero.vue'),
};

// 自定义组件要求以大写字母开头
function isCustomComp(tag) {
  return /^[A-Z]/.test(tag);
}

function pickCustomCompTags(dom) {
  function getTags([tag, , children]) {
    const rs = [];
    rs.push(tag);
    if (Array.isArray(children)) {
      if (children.every(Array.isArray)) {
        children.forEach(child => {
          rs.push(...getTags(child));
        });
        return rs;
      } else if (children.length === 1) {
        return rs;
      }
      rs.push(...getTags(children));
      return rs;
    }
    return rs;
  }

  const tags = getTags(dom);
  return tags.filter(isCustomComp);
}

function createPage(routePath) {
  function parseCfg(node, h) {
    let [tag, attrs, children] = node;

    // Avoid using observed data object as vnode data
    attrs = Object.assign({ props: {} }, attrs);
    attrs.props.pageBus = this.pageBus;

    if (Array.isArray(children)) {
      if (children.every(Array.isArray)) {
        return h(tag, attrs, children.map(child => parseCfg.call(this, child, h)));
      } else if (children.length === 1) {
        // 长度为1，vue将children当做字符串渲染
        return h(tag, attrs, children);
      }
      // 长度不为1，children当做tag渲染，返回VNode，需要包含到数组中
      return h(tag, attrs, [parseCfg.call(this, children, h)]);
    }
    return h(tag, attrs, children);
  }

  const Page = Vue.extend({
    name: 'Page',
    data() {
      return {
        // 用于跨组件通信
        pageBus: new Vue({
          data: {
            state: {},
          },
        }),
      };
    },
    render(h) {
      const cfg = this.$store.state.modularization.PAGES_CFG[routePath];
      if (!cfg || !cfg.dom) {
        // throw new Error(`未找到path：${routePath}对应的配置`);
        return h('div', null, `未找到path：${routePath}对应的配置`);
      }
      return parseCfg.call(this, cfg.dom, h);
    },
    components: {
      ...ASYNC_COMPS,
    },
  });

  //同构框架会执行页面组件的Page.asyncData
  Page.asyncData = function({ store, route }) {
    let cfg = store.state.modularization.PAGES_CFG[routePath];

    if (!cfg || !cfg.dom) {
      return Promise.resolve();
    }

    // 解析自定义函数后，可以得到所有依赖的异步组件
    cfg.dom = parseFn(cfg, Object.assign({}, store.state.rootState, cfg.data));

    return Promise.all(
      pickCustomCompTags(cfg.dom).map(tag => {
        const c = ASYNC_COMPS[tag];
        if (!c) return Promise.resolve();

        return c().then(comp => {
          if (typeof comp.default.asyncData === 'function') {
            return comp.default.asyncData({ store, route });
          }
          return Promise.resolve();
        });
      })
    );
  };

  return Page;
}

export { createPage };
