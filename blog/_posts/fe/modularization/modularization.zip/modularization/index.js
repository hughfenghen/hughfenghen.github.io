export { vuexPlugin } from './cfg-manage';
export { createPage } from './page';
